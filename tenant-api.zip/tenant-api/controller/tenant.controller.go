package controller

import (
	"net/http"

	"github.com/adwinugroho/test-chat-multi-schema/domain"
	"github.com/adwinugroho/test-chat-multi-schema/model"
	"github.com/adwinugroho/test-chat-multi-schema/pkg/logger"
	"github.com/adwinugroho/test-chat-multi-schema/service"
	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
)

type TenantHandler struct {
	service       domain.TenantService
	tenantManager *service.TenantManager
}

func NewTenantHandler(svc domain.TenantService, tm *service.TenantManager) *TenantHandler {
	return &TenantHandler{service: svc, tenantManager: tm}
}

func (h *TenantHandler) NewTenant(c echo.Context) error {
	var req model.NewTenantRequest
	if err := c.Bind(&req); err != nil {
		return c.JSON(http.StatusBadRequest, model.NewError(model.ErrorBadRequest, "Bad request"))
	}

	if err := c.Validate(&req); err != nil {
		return c.JSON(http.StatusBadRequest, err)
	}

	payload := &domain.Tenant{
		TenantID:   uuid.New().String(),
		TenantName: req.TenantName,
	}

	err := h.service.NewTenant(c.Request().Context(), payload)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}

	err = h.service.CreateTenantPartition(c.Request().Context(), payload.TenantID)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}

	err = h.tenantManager.StartConsumer(c.Request().Context(), payload.TenantID)
	if err != nil {
		logger.LogError("Error while start consumer:" + err.Error())
		return c.JSON(http.StatusInternalServerError, model.NewError(model.ErrorGeneral, "Internal server error"))
	}

	return c.JSON(http.StatusOK, model.NewJsonResponse(true).
		SetMessage("Successfully created new tenant, tenant consumer has started...").
		SetData(payload))
}

func (h *TenantHandler) RemoveTenantByID(c echo.Context) error {
	id := c.Param("id")
	if id == "" {
		return c.JSON(http.StatusBadRequest, model.NewError(model.ErrorBadRequest, "Bad request"))
	}

	err := h.tenantManager.StopConsumer(id)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, model.NewError(model.ErrorGeneral, err.Error()))
	}

	err = h.service.RemoveTenantByID(c.Request().Context(), id)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}

	return c.JSON(http.StatusOK, model.NewJsonResponse(true).
		SetMessage("Successfully remove tenant"))
}
